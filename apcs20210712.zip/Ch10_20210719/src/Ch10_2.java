class Rd extends Employee{
	private int bonus;
	Rd(String name,int salary,int bonus){
	super(name,salary);
	this.bonus = bonus;	
	}
	
	public int getSalary() {
		return super.getSalary() + bonus;
	}
}

//
class Manager{
	
}
class Employee {
	private String name;
	private int salary;
	
	Employee(String name,int salary){
		this.name = name;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	public int getSalary() {
		return salary;
	}
	public String toString() {
		return String.format("Name:%s Salary:%d",getName(),getSalary()); 
	}
}
public class Ch10_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp1 = new Employee("Ken",35000);
		System.out.println(emp1);
		Employee emp2 = new Rd("Bom",25000,70000);
		System.out.println(emp2);
				
		
	}

}
