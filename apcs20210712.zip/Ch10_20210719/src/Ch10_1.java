import java.util.ArrayList;
class Student{
	private String name;
	private int age;
	
	Student(String name,int age){
		this.name= name;
		this.age = age;
	}
	
	private ArrayList<Student> friends = new ArrayList<>();
	
	public void addFriend(Student st) {
		friends.add(st);
	}
	
	public boolean isMyFried(Student st) {
		//indexOf �p�G���ۦP��Student�|�^�Ǥj��-1����
		return friends.indexOf(st) > -1;
	}
	
	public boolean removeFried(Student st) {		
		return friends.remove(st);
	}
	public String toString() {
		return name+":"+age;
	}
	//�Ӧ۩�Object
	public boolean equals(Object obj) {
		//A instanceof B  A�O�_��B���� 
		if (obj == null || obj instanceof Student == false) {
			return false;
		}
		Student st = (Student)obj;
		
		return this.age == st.age && this.name.equals(st.name);
	}
}
public class Ch10_1 {
	public static void main(String[] args) {
		Student st1 = new Student("Ken",25);
		Student st2 = new Student("Iris",10);
		Student st3 = new Student("Lucy",18);
		Student st4 = new Student("Bom",31);
		
		Student st6 = new Student("Lucy",18);
		System.out.println(st1);
		
		st1.addFriend(st2);
		st1.addFriend(st3);
		st1.addFriend(st4);
		System.out.println(st6.equals(st3));
		System.out.println(st1.isMyFried(st6));
		
		
	}
}
