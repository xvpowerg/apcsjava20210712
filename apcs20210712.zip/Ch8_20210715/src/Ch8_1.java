//�غc�� ���|�Q�~��
class Cat extends Animal{
	Cat(){}
	Cat(String name,float height,float weight){
		//�I�s�����O���غc��
		super(name,height,weight);
	}
}
class Dog extends Animal{
	Dog(){
		
	}
Dog(String name,float height,float weight){
	//super() �|�I�s�����O�غc��
	super(name,height,weight);
//	this.setName(name);
//	this.setHeight(height);
//	this.setWeight(weight);	
	}
	//�Ƽg �|������O���\���л\
	public void print() {
		//�I�s�����O����k
		System.out.print("Dog ");
		super.print();
		
	}

}
class Animal{
	private String name;
	private float height;
	private float weight;
	//�w�]�غc��
	Animal(){
		//setName("����g");
		//�u��b�غc���I�s
		//�I�s�t�@�իغc��
		this("����g",0,0);
	}
	Animal(String name,float height,float weight){
		setName(name);
		setHeight(height);
		setWeight(weight);
	
	}
	//�]�w
	public void setName(String name) {
		this.name = name;
	}
	//Ū��
	public String getName() {
		return name;
	}
	
	public void setHeight(float height) {
		this.height = height;
	}
	
	public float getHeight() {
		return height;
	}
	
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public float getWeight() {
		return weight;
	}
	
	public void print() {
		System.out.printf("name:%s height:%.2f weight:%.2f %n",getName(),getHeight(),getWeight());
	}
}

public class Ch8_1 {
	
	public static void main(String[] args) {
		Animal an1 = new Animal();
		an1.setName("Dodo");
		an1.setHeight(25);
		an1.setWeight(2);
		an1.print();
		
		Animal an2 = new Animal("Tom",12,0.5f);
		an2.print();
		
		Animal an3 = new Animal();
		an3.print();
		
		Dog dog1 = new Dog();
		dog1.setHeight(50);
		dog1.setWeight(5);
		dog1.setName("LuLu");
		dog1.print();
		
		Dog dog2 = new Dog("Yum",16,30f);
		dog2.print();
		//�h��
		Animal an4 = new Dog("Momo",30,70f);
		an4.print();
		an4 = new Cat("Kitty",40,90f);
		an4.print();
		
	}
	
}
