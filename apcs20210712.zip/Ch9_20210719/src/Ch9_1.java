import java.util.Scanner;
public class Ch9_1 {

	public static void main(String[] args) {
		
		
		
		 //3 5
		// 5 6 7 8 9
	    // 10 11 12 13 14
		// 15 16 17 18 19
		
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		 //3 5
		// 5 6 7 8 9
	    // 10 11 12 13 14
		// 15 16 17 18 19
		int r = scan.nextInt();
		int c = scan.nextInt();
		int[][] array = new int[r][c];
		for (int i = 0;i < r;i++) {
			for (int k = 0;k < c;k++) {
				int v = scan.nextInt();	
				array[i][k] = v;
			}
		}

	
		for (int v1[] :array) {
			for (int v2 : v1) {
				System.out.print(v2+" ");
			}
			System.out.println();
		}
		
	}

}
