import java.util.ArrayList;
class Student{
	private String name;
	private int age;
	
	private ArrayList<Student> friends = new ArrayList();
	
	public void addFriend(Student st) {
		friends.add(st);
	}
	
	public boolean isMyFried(Student st) {
		//indexOf �p�G���ۦP��Student�|�^�Ǥj��-1����
		return friends.indexOf(st) > -1;
	}
	
	public boolean removeFried(Student st) {		
		return friends.remove(st);
	}
	public String toString() {
		return name+":"+age;
	}
}
public class Ch9_15 {

}
