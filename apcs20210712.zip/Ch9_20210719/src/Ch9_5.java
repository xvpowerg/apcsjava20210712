
public class Ch9_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Java";
		//�걵 s1 + SCJP
		s1 = s1.concat("SCJP");
		System.out.println(s1);
		String s2 = "Java";
		s2 = s2.replace("J", "I");
		System.out.println(s2);
		
	}

}
