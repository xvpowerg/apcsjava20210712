import java.util.ArrayList;

class User{
	private String name;
	private int salary;
	
	User(){}
	User(String name,int salary){
		this.name = name;
		this.salary = salary;		
	}
	
	void print() {
		System.out.print(name+":"+salary+" ");
	}
}

public class Ch9_14 {

	public static void main(String[] args) {
		User[] userArray = new User[3];
		userArray[0] = new User("Ken",100);
		userArray[1] = new User("Lucy",75);
		userArray[2] = new User("Vivin",92);
		for (User user : userArray) {
			user.print();
		}
		System.out.println();
		//�Q�bArrayList��User????
		ArrayList<User> userList = new ArrayList<>();		
		userList.add(new User("Join",81));
		userList.add(new User("Iris",71));
		userList.add(new User("Tom",150));
		for(User u : userList) {
			u.print();
		}
		
	}

}

