class Rectangle{
	int width;
	int height;
	Rectangle(){
		this(25,10);
	}
	Rectangle(int width,int height){
		this.width = width;
		this.height = height;
	}
	
	public int getArea() {
		return width * height;
	}
	
	public void draw() {
		
		for (int r= 1; r <= height;r++) {
			
			for (int c= 1;c <= width;c++) {
				
				System.out.print("*");
			}
			System.out.println();
			
		}
		
	}
	
}
public class Ch9_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle(3,2);
		System.out.println(r1.getArea());
		r1.draw();
		Rectangle r2 = new Rectangle();
		System.out.println(r2.getArea());
		r2.draw();
	}

}
