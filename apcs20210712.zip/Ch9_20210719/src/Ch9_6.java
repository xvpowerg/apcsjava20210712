
public class Ch9_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg = "Ken,Vivin,Lucy,Iris";
		String[] msgArray = msg.split(",");
		for (String name : msgArray) {
			System.out.println(name);
		}
	}

}
