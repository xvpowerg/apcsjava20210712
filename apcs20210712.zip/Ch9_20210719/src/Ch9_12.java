import java.util.Arrays;

public class Ch9_12 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]array1 = new int[10];
		int[][]array2 = new int[5][7];
		int[]array3 = {5,6,7,1,3};
		int[][]array5 = {{1,2,3},
						 {5,6,7}};
		//�w�]���p�U�D�򥻫��A��null
		String[] array4 = new String[5];
		Arrays.fill(array4, "");
		for (int v : array3) {
			System.out.print(v+" ");
		}
		
		System.out.println();
		for (String v : array4) {			
			System.out.print(v.toUpperCase()+" ");
		}
	}

}
