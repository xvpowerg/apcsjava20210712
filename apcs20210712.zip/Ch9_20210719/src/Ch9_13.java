import java.util.ArrayList;
public class Ch9_13 {
	public static void main(String[] args) {
		//<Integer> ���w ArrayList �u���Integer
		ArrayList<Integer> list = new ArrayList<>();
		list.add(100);
		list.add(50);
		list.add(72);
		list.add(15);
		
		for (int v : list) {
			System.out.print(v+ " ");
		}
		System.out.println();
		//�������į�n
		int r = list.remove(list.size()-1);
		System.out.println("Remove:"+r);
		
		for (int v : list) {
			System.out.print(v+ " ");
		}
	}
}

