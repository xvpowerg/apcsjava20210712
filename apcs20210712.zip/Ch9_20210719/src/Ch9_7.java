
public class Ch9_7 {
	public static void main(String[] args) {
		int id = 25;
		String name = "���j�Y";
		float weight = 98.56f;
		
		System.out.printf("id:%d �m�W:%s �魫:%.2f %n",id,name,weight);
		
		String fStr = String.format("id:%d �m�W:%s �魫:%.2f %n",id,name,weight);
		System.out.println(fStr);
	}
}
