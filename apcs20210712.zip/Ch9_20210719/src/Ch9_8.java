
public class Ch9_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// str  
		String str = "1221";
		char[] charArr =str.toCharArray();
		char[] tmpArray = new char[charArr.length];
		
		
		//reverse
		for(int i =charArr.length -1,k=0; i>=0;i--,k++) {
			tmpArray[k] = charArr[i];
		}
//		for (char c : tmpArray) {
//			System.out.print(c);			
//		}
		String st2 = new String(tmpArray);		
		
		System.out.println(str.equals(st2));
	}

}
