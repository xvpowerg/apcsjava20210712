
class Test1{
	private int x1;
	private int x2;
	private String s1;
	//�S���غc�� �|�w�]�إߤ@�իغc��
	Test1(){
		System.out.println("Test1");
	}
	
	Test1(int v){
		this(v,0,"");		
		System.out.println("Test1:"+v);
	}
	Test1(int v1 ,int v2,String v3){
		x1 = v1;
		x2 = v2;
		s1 = v3;
	}
	void print() {
		System.out.printf("%d:%d:%s%n",x1,x2,s1);
	}
}

public class Ch9_2 {
	
	
		public static void main(String[] args) {
			Test1 t1 = new Test1(1,2,"T");
			Test1 t2 = new Test1(8);
			t1.print();
			t2.print();
		}
}
