
public class Ch9_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String st1 = "Java";
		String st2 = "Java";
		String st3 = new String("Java");
		System.out.println(st1 == st2);
		System.out.println(st1 == st3);
		System.out.println(st1.equals(st3));
		
		
		String st4 = "Php";
		String upCase =st4.toUpperCase();
		System.out.println(upCase);
		//���s���w
		st4 = "C sharp";
		System.out.println(st4);
		
		
		
	}

}
