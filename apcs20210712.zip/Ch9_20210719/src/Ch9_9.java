
public class Ch9_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ABBA";
		//��r���ন�r���}�C
		char[] charArr =str.toCharArray();
		boolean isPalindrome = true;
		for (int i=charArr.length-1,k=0;i > k;i--,k++) {
			if (charArr[i] != charArr[k]) {
				isPalindrome = false;
				break;
			}
		}
		
		if (isPalindrome) {
			System.out.println("Pass");
		}else {
			System.out.println("Fail");
		}
	}

}
