
public class Ch6_6 {
	public static void main(String[] args) {
		int[][] array2;
		array2 = new int[2][3];
		
		array2[0][0] = 1;
		array2[0][1] = 2;
		array2[0][2] = 3;
		
		array2[1][0] = 5;
		array2[1][1] = 7;
		array2[1][2] = 8;
		
		System.out.println(array2[0][1]);
		//array2.length ���o2
//		for (int i = 0; i < array2.length;i++) {
//			//array2[i].length ���o3
//			for (int k = 0;k < array2[i].length;k++) {
//				System.out.print(array2[i][k]+" ");
//			}
//			System.out.println();
//		}
		//  for each ���X�G���}�C
	   for(int[] tmpArray : array2) {
		   
		   for (int v : tmpArray) {
			   System.out.print(v+" ");
		   }
		   		System.out.println();
		   
	   }
	
		
	}
}
