
public class Ch6_2 {
	//Dynamic Programming  DP
	static long f2(int n,long[] tmp) {			
		if (tmp[n-2] == 0) {
			tmp[n-2] = f2(n-2,tmp);
		}
		if (tmp[n-1] == 0) {
			tmp[n-1]  = f2(n-1,tmp);
		}
		return tmp[n-2] + tmp[n-1];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long[] tmp = new long[60];
		tmp[1]=1;
		tmp[2]=1;
	   System.out.println(f2(60,tmp));
	}

}
