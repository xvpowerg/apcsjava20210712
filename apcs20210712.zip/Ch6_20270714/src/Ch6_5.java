import java.util.Arrays;
public class Ch6_5 {

	public static void main(String[] args) {
		int[] array1= new int[10000];
		System.out.println(array1[5]);
		Arrays.fill(array1,-1);
		System.out.println(array1[5]);
		
		int[] array2= {5,9,1,2,7,11,16,21};
		int[]copyArray= Arrays.copyOf(array2, 6);
		for (int v : copyArray) {
			System.out.print(v+" ");
		}
		
	}

}
