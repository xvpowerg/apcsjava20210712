
public class Ch6_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1;
		array1 = new int[5];
		array1[1] = 10;
		array1[3] = 25;
		array1[4] = 78;
		
		//System.out.println(array1[3]);
		
//		for (int i =0 ;i < array1.length;i++) {
//			System.out.print(array1[i]+" ");
//		}
		//for each
		for (int v : array1) {
			System.out.print(v+" ");
		}
		
		
	}

}
