
public class Ch6_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {8,2,1,5,6};
		
		int sum = 0;
		for (int v : array1) {
			//�u�����ƪ��~�[�`!
		    if (v % 2 == 0) sum += v;
		}
		System.out.println(sum);
		
	}

}
