
public class Homework3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n= 8;
		boolean isPrime = true; 
		for (int i = 2;i < n;i++) {
			if (n % i == 0) {
				System.out.println("���O���!");
				isPrime = false;
				break;
			}
		}
		
//	   if(i == n) {
//		   System.out.println("�O���!");   
//	   }
		
		if (isPrime ) {
			System.out.println("�O���!");
		}
	}

}
