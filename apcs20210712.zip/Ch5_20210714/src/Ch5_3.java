
public class Ch5_3 {
	//���j�@�w���@�ӳ�return���I	
	static void test1(int n) {
		System.out.print(n+" ");
		if (n < 5)
		test1(n + 1);
		System.out.print(n+" ");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test1(1);
	}

}
