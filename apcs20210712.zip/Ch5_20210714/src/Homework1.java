
public class Homework1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c = 100;
		float f = 9/5.0f*c + 32;
		System.out.printf("%.2f",f);
		
		
		
	}

}
