
public class Ch5_1 {

	
	static void testFunc() {
		System.out.println("Test1!!");
	}
	
	static int add(int a,int b) {		
		return a + b;
	}
	
	//static �u��I�sstatic
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testFunc();
		int ans = add(2,10);
		System.out.println(ans);
	}

}
