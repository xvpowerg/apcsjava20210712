
public class Homework2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 int n = 19;
	 
	 String msg = n%2==0 ?"����":"�_��";
	 System.out.println(msg);
	}

}
