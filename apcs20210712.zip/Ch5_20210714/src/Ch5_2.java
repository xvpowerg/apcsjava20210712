
public class Ch5_2 {
	
	static void test3(int z) {
		System.out.println("Test3!!"+z);
	}
	static void test2(int y) {
		System.out.println("Test2!!"+y);
	}
	static void test1(int k) {
		k++;
		test2(k);
		k++;
		test3(k);
		System.out.println("Test1!!");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test1(1);
	}

}
