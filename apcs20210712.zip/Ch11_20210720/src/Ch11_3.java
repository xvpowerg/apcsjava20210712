import java.math.BigInteger;

public class Ch11_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BigInteger b1 = new BigInteger("92233720368547758071312");
		BigInteger b2 = new BigInteger("92233720368547758071231");
		BigInteger b3 = b1.add(b2);
		System.out.println(b3.toString());
	}

}
