
public class Ch11_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] array= {15,8,9};
			int subCount = 1 << array.length;
			//System.out.println(subCount);
			
			for (int i =0;i<subCount;i++) {
				//10�i����2�i�� �^�ǬO�r��
//			String bstr = Integer.toBinaryString(i);
//				System.out.printf("%d:%03d %n",i,Integer.parseInt(bstr));
				 for (int k = 0; k < array.length;k++) {
					 if ( (i & (1 << k))  > 0) {
						 System.out.print(array[k]+" ");	 
					 }					
				 }
				 System.out.println();
			}
		
			//�Darray���Ҧ��l��
			//2^3
//			        �ť�
/*				9
 				8
				8 9
				15
				15 9
				15 8
				15 8 9
			
*/			

	}

}
