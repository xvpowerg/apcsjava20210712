
interface Fly{
	//�w�]public abstract 
	void flying();
}

interface Run{	
	void runing();
}
interface Magic{
	String sendMagic(int type);
}
//�s��
interface DoctorSkill extends Fly,Run,Magic{
	
}

class Bird implements Fly{
	public void flying() {
		System.out.println("�����I�I");
	}
}


class DoctorStrange implements DoctorSkill {
	public void runing() {
		System.out.println("�k�]�����դh");
	}
	public void flying() {
		System.out.println("�Ť������դh");
	}
	public String sendMagic(int type) {
		switch(type) {
		case 1:
			return "�Ŷ��]�k";
		case 2:
			return "���K�]�k";
		default:
			return "���m�]�k";
		}		
	}
}

//�����i�h����@
class Chocobo implements Fly,Run{
	public void flying() {
		System.out.println("Chocobo Fly");
	}
	public void runing() {
		System.out.println("Chocobo Run");
	}
}


public class Ch11_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fly f1 = new Bird();
		f1.flying();
		Chocobo ch1 = new Chocobo();
		Fly f2 = ch1;
		f2.flying();
		Run run2 = ch1;
		run2.runing();
		
		DoctorSkill dsk = new DoctorStrange();
		dsk.flying();
		dsk.runing();
		System.out.println(dsk.sendMagic(1));
		
	}

}
