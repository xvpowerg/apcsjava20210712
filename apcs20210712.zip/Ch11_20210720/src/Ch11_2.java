import java.util.ArrayList;

abstract class Animal{
	private String name;
	private int age;
	
	public Animal(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public abstract void bark();
	
	public String toString() {
		return this.getName()+":"+this.getAge();
	}
	
}
class Dog extends  Animal{
	public Dog(String name,int age) {
		super(name,age);
	}
	public void bark() {
		System.out.println("�p�p!");
	}
	
	public String getName(){
		return "Dog:"+super.getName();
	}
}

class Cat extends Animal{
	public Cat(String name,int age) {
		super(name,age);
	}
	public void bark() {
		System.out.println("�L�L!");
	}
}
public class Ch11_2 {

	public static void main(String[] args) {
		//�]��Animal�O��H���ҥH����new
		//Animal anima = new Animal("DoDo",2);
		//System.out.println(anima);
		//anima.bark();
		//�h��
		Animal anima2 = new Dog("BoBo",3);
		System.out.println(anima2);
		anima2.bark();
		
		ArrayList<Animal> list = new ArrayList<>();
		list.add(new Dog("Candy",5));
		list.add(new Cat("DoDo",2));
		list.add(new Dog("QB",3));
		for (Animal an : list) {
			System.out.print(an);
			an.bark();
		}
	}

}
