import java.util.Scanner;
public class Ch2_10 {
			public static void main(String[] args) {
				Scanner scan = new Scanner(System.in);
				System.out.print("�п�J���B:");
				int money = scan.nextInt();
				float price = 0;
				if (money >= 5000) {
					price = money * 0.7f;
				}else if(money >= 3000) {
					price = money * 0.8f;
				}else if(money >= 2000) {
					price = money * 0.85f;
				}else {
					price = money * 0.9f; 
				}
				
				System.out.printf("%.2f%n",price);
			}
}
