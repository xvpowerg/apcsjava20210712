
public class Ch2_7 {
	public static void main(String[] args) {
		int a=20,b=10;
		System.out.println("Ans:"+a+b);
		System.out.println("Ans:"+(a+b));
		
	}
}
