
public class Ch2_5 {
	public static void main(String[] args) {
		/*int a = 10,b =20;
		int tmp = a;
		a = b;
		b = tmp;
		System.out.println(a+":"+b);*/
		int c = 10,e =20;
		c = c ^ e;
		//System.out.println(c ^ e);		
		e = c ^ e;//c^e�o�� c���ƭ�10
		c = c ^ e; //c^e�o�� �쥻e����20
		
		System.out.println(c+":"+e);
	}
}
