
public class Ch2_6 {
	public static void main(String[] args) {
		int value = 100;
		System.out.println(value/2);
		System.out.println(value >> 1);//����2
		
		int n = 6;
		System.out.println(1 << n);//1 * 2��5����
		
		int a = 32 << 2;
		System.out.println(a);
		
		
	}
}
