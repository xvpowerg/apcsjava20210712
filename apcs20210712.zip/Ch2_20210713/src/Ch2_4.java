
public class Ch2_4 {
		public static void main(String[] args) {
			int a = 10,b=5;
			boolean x = a++ > 10 && b--<5;
			System.out.println(x);
			System.out.println(a);
			System.out.println(b);
			
			
			
		}
}
