
public class Ch2_8 {
	public static void main(String[] args) {
		short a = 1,b = 2;
		short c = (short)(a + b);
		System.out.println(c);
		
//		final short a = 1,b = 2;
//		short c = a + b;
//		System.out.println(c);
	}
}
