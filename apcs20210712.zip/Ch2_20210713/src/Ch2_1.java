
public class Ch2_1 {
   public static void main(String[] args) {
//	   int a = 0,b = 0;
//	   b = a++ + ++a;
	//     0   + 2
//	   System.out.println(a+":"+b);
	   
	   int c = 0,e = 0;
	   e = c-- - --c;
	//     0   -  -2   
	   System.out.println(c+":"+e);
	   
	   
   }
}
