
public class Ch2_2 {
	public static void main(String[] args) {
		int a = 20 ,b =20;
		System.out.println(a > b);
		System.out.println(a < b);
		System.out.println(a <= b);
		System.out.println(a >= b);
		System.out.println(a == b);
		System.out.println(a != b);

		
	}
}
