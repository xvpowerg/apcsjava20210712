
public class Ch4_1 {
	public static void main(String[] args) {
		char x = 'A';
		final char valueA = 'A';
		switch(x) {
		case valueA:
		System.out.println("A");
			break;
		case 'B':
			System.out.println("B");
			break;
		}
		
		
		
	}
}
