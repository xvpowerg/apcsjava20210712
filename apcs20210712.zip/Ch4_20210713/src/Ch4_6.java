import java.util.Scanner;
public class Ch4_6 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("�п�J����:");
		int h=scan.nextInt();
		char msg = 'A';
		for (int i = 1,c=1;i<=h;i++,msg++,c+=2) {
			for (int b=1;b<= h-i;b++) {
				System.out.print(" ");
			}
			
			for (int k = 1;k<= c;k++) {
				System.out.print(msg);				
			}
			System.out.println();
			
		}
		
		
	}
}
