
public class Ch4_3 {
	
	
	public static void main(String[] args) {
		long f1 = 0;
		long f2 = 1;		
		int f = 6;
		while(--f >=1) {
			long tmp = f2;
			f2 = f1 + f2;
			f1 = tmp;
		}
		System.out.println(f2);
		
		
	}
}
