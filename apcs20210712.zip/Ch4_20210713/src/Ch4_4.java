
public class Ch4_4 {
	public static void main(String[] args) {
		/*for (int i = 1,k=4; i<=5 ;i++,k--) {
			System.out.println(i+":"+k);
		}*/	
	
		int count = 0;
		for (int k = -5; k <=7;k++) {
			System.out.print(k+" ");
			count++;
			
		}
		System.out.println();
		System.out.println(count);
		
	}
	
}
