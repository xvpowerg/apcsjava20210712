import java.util.Scanner;
public class Ch4_2 {
    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
    	System.out.print("�п�J�褸�~:");
    	int year = scan.nextInt();
    	System.out.print("�п�J���:");
    	int month = scan.nextInt();
    	int day = 31;
    	switch(month) {	
    	case 4:
    	case 6:	
    	case 9:
    	case 11:
    		day=30;
    	break;		
    	case 2:
    		if (year % 400 == 0 || (year %4 == 0 && year %100 != 0)) {
    			day=29;	
    		}else {
    			day=28;
    		}
    	break;	
    }
    	System.out.println(day);
    	
    	
    	String dayStr= "Mon";
    	switch(dayStr) {
    	case "Mon":
    		System.out.println("���^��");
    		break;
    	case "Tue":
    		System.out.println("��ѽ�");
    		break;		
    	}
    }
}
