
public class Ch4_7 {
	public static void main(String[] args) {
		
		int i = 1;
		while(i > 0) {
			if (i==7) break;
			System.out.print(i+"\t");
			i++;
			
		}
		
	}
}
