
public class Ch4_8 {
	
	public static void main(String[] args) {
		label:
		for (int i =1;i<=5;i++) {			
			for (int k = 1;k<=3;k++) {
				System.out.printf("Str %d_%d ",i,k);
				if(i== 3) break label;
				System.out.printf("End %d_%d ",i,k);
			}
			System.out.println();
			
		}
		
		
	}
}
