import java.util.Scanner;
public class Ch4_5 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("��:");
		int len = scan.nextInt();
		System.out.print("�e:");
		int w = scan.nextInt();
//		for(int i = 1;i<= w;i++) {
//			for (int k =1 ;k<=len;k++) {
//				System.out.print("@");				
//			}
//			System.out.println();
//		}
		
		//��@while�j��
		int k = 1,x=1;		
		while(true) {
			if (k <= len) {
				System.out.print("@");
				k++;
			}else {
				System.out.println();
				k = 1;
				if (x == w) break;
				x++;
			}
			
		}
		
		
	}
}
