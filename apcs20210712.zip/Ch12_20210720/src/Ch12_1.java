import java.util.Arrays;
class Item implements Comparable<Item>{
	private int id;
	private String name;
	
	Item(int id,String name){
		this.id = id;
		this.name = name;
	}
	public String  toString() {
		return id+":"+name;
	}
	// �w�]���p �p��j
	// �ثe�ƭ� �j�� �ǤJ �^�ǥ���
	// �ثe�ƭ� ���� �ǤJ�ƭ� 0
	// �ثe�ƭ� �p�� �ǤJ �^�ǭt��
	public int compareTo(Item item) {
		  if (id > item.id) {
			  return 1;
		  }else if(id < item.id) {
			  return -1;
		  }
		  return name.compareTo(item.name);
	}	
}
public class Ch12_1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] array = {8,10,25,60,11,9};
			Arrays.sort(array);
		   for (int v : array) {
				   System.out.print(v+" ");
		   }
		   System.out.println("==================");
		   
		   Item[] arrayItm = new Item[6];
		   arrayItm[0] = new Item(8,"A");
		   arrayItm[1] = new Item(5,"C");
		   arrayItm[2] = new Item(7,"B");
		   arrayItm[3] = new Item(6,"D");
		   arrayItm[4] = new Item(1,"E");
		   arrayItm[5] = new Item(5,"A");
		   Arrays.sort(arrayItm);
		for (Item itm : arrayItm) {
			System.out.print(itm+" ");
		}
	}

}
