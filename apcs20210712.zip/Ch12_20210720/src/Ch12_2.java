import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.function.Predicate;
class MyStComparator implements Comparator<Student>{
	
	//���j��k ����
	//������k 0
	//���p��k �t��
	public int compare(Student st1,Student st2) {
//		 if (st1.getScore1() > st2.getScore1()) {
//			 return 1;
//		 }else if (st1.getScore1() < st2.getScore1()) {
//			 return -1; 
//		 }
//		 return 0;
		int cmp = st1.getScore1() - st2.getScore1();				
		if (cmp != 0) return cmp;		
		cmp = st1.getScore2() - st2.getScore2();
		if (cmp != 0) return cmp;
		cmp = st1.getScore3() - st2.getScore3();
		if (cmp != 0) return cmp;
		cmp = st1.getName().compareTo(st2.getName());
		return cmp;
		
	}
}

class Student{
	private int score1;
	private int score2;
	private int score3;
	private String name;
	Student(String name,int score1,int score2,int score3){
		this.score1 = score1;
		this.score2 = score2;
		this.score3 = score3;
		this.name  = name;
	}
	
	
	public String getName() {
		return this.name;
	}
	public int getScore1() {
		return this.score1;
	}
	
	public int getScore2() {
		return this.score2;
	}
	public int getScore3() {
		return this.score3;
	}
	
	public String toString() {
		return name+":"+score1+":"+score2+":"+score3;
	}
}

class PrintValue implements Consumer<Student>{
	boolean println=true;
	PrintValue(boolean println){
		this.println = println;
	}
	public void accept(Student st) {
		if (println)
		System.out.println(st);
		else
		System.out.print(st+" ");
	}
}

class RemovePredicate implements Predicate<Student>{
		private String name;
		RemovePredicate(String name){
			this.name = name;
		}
	//�i�H�]�w�o���� �p�G�OKen �� Tom ������...
	public boolean test(Student st) {
		return st.getName().equals(name);
	}
}
public class Ch12_2 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st1 = new Student("Ken",72,83,91);
		Student st2 = new Student("Iris",25,84,65);
		Student st3 = new Student("Join",85,100,26);
		Student st4 = new Student("Lucy",72,83,45);
		Student st5 = new Student("Tom",72,37,91);
		ArrayList<Student> stList = new ArrayList<>();
		MyStComparator cmp = new MyStComparator();
		stList.add(st1);
		stList.add(st2);
		stList.add(st3);
		stList.add(st4);
		stList.add(st5);
		//stList.sort(cmp);
		//lambda
		Comparator<Student> cmp2 =  Comparator.comparing(st->st.getScore1());
		cmp2 = cmp2.thenComparing(st->st.getScore2()).thenComparing(st->st.getScore3()).
		thenComparing(st->st.getName());
		stList.sort(cmp2);
//		for (Student st : stList) {
//			System.out.print(st+" ");
//		}
		PrintValue pv = new PrintValue(false);
		stList.forEach(pv);
		RemovePredicate rp = new RemovePredicate("Ken");
		stList.removeIf(rp);
		System.out.println();
		stList.forEach(pv);
	}

}

