
public class Ch7_4 {
	
	//�h��
	//�i�H�٥h�g�ܦh���P��k�W��
	
	static float max(float a,float b) {
		return a > b ? a: b;
	}
	
	
	static int max(int a,int b) {			
		return a > b ? a:b;
	}
	
	public static void main(String[] args) {
		System.out.println(max(25,7));
		System.out.println(max(1.5f,7.1f));	
	}
}
