
class Student{
	String name;
	int age;
	int[] scores = new int[3];
	
	void print() {
		String scoreStr ="";
		for (int s : scores) {
			scoreStr += s+" ";
		}
		System.out.printf("�m�W:%s �~��:%d ���Z:%s%n",name,age,scoreStr);
	}
	//���Z�[�`
	//sum
	int sum() {
		int sum = 0;
		for (int s : scores) {
			sum += s;
		}
		return sum;
	}
	//���Z������
	float avg() {
		float count = scores.length;
		return sum() / count;
	}
}

public class Ch7_5 {
	public static void main(String[] args) {
		
		Student st1;
		st1 = new Student();
		st1.name = "Ken";
		st1.age = 12;
		st1.scores[0] = 25;
		st1.scores[1] = 80;
		st1.scores[2] = 18;
		st1.print();
	
		System.out.printf("%.2f%n", st1.avg());
		
	Student st2 = new Student();
	st2.name = "Vivin";
	st2.age = 15;
	st2.scores[0] = 71;
	st2.scores[1] = 83;
	st2.scores[2] = 65;
	st2.print();
	System.out.printf("%.2f%n", st2.avg());
	}
}
