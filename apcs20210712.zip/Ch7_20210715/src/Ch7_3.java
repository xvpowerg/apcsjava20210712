
public class Ch7_3 {

	//���Ѽ�
	static int  testVargs(int ... a ) {
		int sum = 0;
			for (int v : a) {
				sum+= v;
			}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(testVargs(10,20,40));
		
	}

}
