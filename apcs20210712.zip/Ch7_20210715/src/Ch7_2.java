
public class Ch7_2 {
	
	//�Ҧ��򥻫��A���Ocall by value
	static void swap(int a,int b) {
		int tmp = a;
		a = b;
		b = tmp;
		
	}
	//call by reference �i��|���� �ǤJ�ܼƪ��ƭ�
	static void swpaArray(int[] testArray) {
		int tmp = testArray[0];
		testArray[0] = testArray[1];
		testArray[1] = tmp;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int a = 10, b =20;
//		
//		swap(a,b);
//		System.out.println(a+":"+b);
		int[] array1 = {10,50};
		System.out.println(array1[0]);
		System.out.println(array1[1]);
		System.out.println("=====================");
		swpaArray(array1);		
		System.out.println(array1[0]);
		System.out.println(array1[1]);
	}

}
