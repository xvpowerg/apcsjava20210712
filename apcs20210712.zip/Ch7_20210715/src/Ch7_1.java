
public class Ch7_1 {
	public static void main(String[] args) {
		int[][] array1= {{1,4},
						 {2,5},
						 {3,6}};
					
		for (int i = 0;i < array1.length;i++) {
			for (int k =0 ;k < array1[i].length;k++) {
				System.out.print(array1[i][k]+" ");
			}
			System.out.println();
		}
		
		//0 0 swap 2 0
		//0 1 swap 2 1
		
		for (int i = 0,end=array1.length -1; end > i ;i++,end--) {
			for (int c = 0;c <array1[i].length ;c++) {
				int tmp = array1[i][c];
				array1[i][c] = array1[end][c];
				array1[end][c] = tmp;
//				System.out.println(i+":"+c);	
//				System.out.println("swap");
//				System.out.println(end+":"+c);
			}
				System.out.println();
		}
		
		
		System.out.println("=========================");
		for (int i = 0;i < array1.length;i++) {
		  for (int k =0 ;k < array1[i].length;k++) {
			System.out.print(array1[i][k]+" ");
		  }
		System.out.println();
		}
		System.out.println("=========================");
		//���� 
		int[][] rArray = new int[array1[0].length][array1.length];		
		for (int i = 0,k = array1.length-1 ; i <array1.length;++i,k--) {
			
			for (int x = 0;x < rArray.length;x++) {
				System.out.printf("%d %d = %d %d%n",x,i,k,x);					
			}
			System.out.println();
		}
		
		
	}
}
