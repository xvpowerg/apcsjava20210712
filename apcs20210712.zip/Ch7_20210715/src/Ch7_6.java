class Employee{
	String name;
	int age;
	String pNum;
	//private�٬��ʸ�
	//�i�H���w�}�o�H�� �u��ѬY�ӤJ�f Ū�g��� 
	private int[] salarys = new int [12];
	private int sum = 0;//
	void addSalary(int month,int salary) {
		if (salarys[month-1] == 0) { 
			salarys[month-1]= salary;	
			sum += salary;
			};		
	}
	int getSum() {
		return sum;
	}
	//�~��[�`
	//�����~�~	
	float getAvg() {
		return getSum()/12f;
	}
	
	//�Ʊ�H�U��k�ϥάۦP����k�W��
	// setEmpInfo()
	// �Ʊ�i�H�P�ɳ]�w name �P age  �P pNum
	//  �Ʊ�i�H�P�ɳ]�w name �P age
	//this ���ܷ��e���󪺬ƻ�F��
	void setEmpInfo(String name,int age,String pNum) {
		this.name = name;
		this.age = age;
		this.pNum = pNum;
	}

	void setEmpInfo(String name,int age) {
		setEmpInfo(name,age,"");
//		this.name = name;
//		this.age = age;
	}
}


public class Ch7_6 {
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.name="Ken";
		emp.age = 15;
		emp.addSalary(1, 28000);
		emp.addSalary(2, 28000);
		emp.addSalary(3, 28000);
		emp.addSalary(4, 28000);
		emp.addSalary(5, 28000);
		emp.addSalary(6, 28000);
		emp.addSalary(7, 28000);
		emp.addSalary(8, 28000);
		emp.addSalary(9, 28000);
		emp.addSalary(10, 28000);
		emp.addSalary(11, 28000);
		emp.addSalary(12, 28000);

		System.out.println(emp.getSum());
		System.out.println(emp.getAvg());

		Employee emp2 = new Employee();
		emp2.setEmpInfo("Vivin", 18, "0988117552");
		System.out.println(emp2.name);
	}
}
