
import java.awt.Color;

import ch.aplu.turtle.Turtle;

public class Ch1_2 {

  public static void main(String[] args) {
	  //Turtle t = new Turtle();
		Turtle t = new Turtle();
		t.setColor(Color.RED);
		t.setPos(-50, 50);
		t.setLineWidth(5.0);
		for (int i = 1;i<=4;i++) {
		t.forward(100);	
		t.left(90);
		}
		
  }
}
